const _t = (str) => {
    return str.replace(/ +/g, "_");
}

export {
    _t
}