# Usage
- build frontend first
- copy build to the public in backend
- deploy  backend to vps

# Github
- url: https://github.com/daltonbreka/nodejs-mysql-firebase-payment-backend-chollo.git