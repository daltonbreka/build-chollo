module.exports = { 
    secret: `This is JWT TOKEN SECRET`,
    ttl: 3000000
}