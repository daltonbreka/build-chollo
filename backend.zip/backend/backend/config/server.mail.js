module.exports = { 
    mail: "montakesau@outlook.com",
    password: "Montake123"
}