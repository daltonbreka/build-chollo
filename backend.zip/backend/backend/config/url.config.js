module.exports = {
    SERVER_URL: "https://www.chollitos.net/"
}