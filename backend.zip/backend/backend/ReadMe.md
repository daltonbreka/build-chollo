1) Create Credential in the external site.
2) Register it in console of firebase and set settings.

3) Diagram:
https://app.diagrams.net/#G1sLEaFMXk71Icd1fEZllI1iw9hXGjYOK2