module.exports = { 
    secret: `${process.env.JWT_SECRET}`,
    ttl: 3000000
}