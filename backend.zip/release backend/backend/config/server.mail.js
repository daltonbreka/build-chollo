module.exports = { 
    // mail: process.env.SERVER_MAIL,
    // password: process.env.SERVER_MAIL_PASSWORD,
    mail: "gracephilipse@outlook.com",
    password: "Grace123",
    gmail: process.env.SERVER_GMAIL,
    gmail_password: process.env.SERVER_GMAIL_PASSWORD,
}