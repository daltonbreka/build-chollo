module.exports = {
    // SERVER_URL: `${process.env.SERVER_URL}`
    SERVER_URL: "https://www.chollitos.net/"
}