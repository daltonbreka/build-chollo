# Usage
- Use postman apis only named "... aws".

# Postman API
https://www.postman.com/restless-meteor-712416/workspace/my-workspace/overview

# Github
- url: https://github.com/daltonbreka/nodejs-mysql-firebase-payment-backend-chollo.git


